package com.example.quickscanner

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class AnalysisResult(
    val timeframe: String,
    val trend: String,
    val signal: String,
    val confidence: Int,
    val bullishScore: Int = 0,
    val bearishScore: Int = 0
)

object CandleAnalyzer {

    private const val MIN_CANDLES = 5
    private const val MAX_CANDLES = 100

    private const val TOP_RATIO = 0.15f
    private const val BOTTOM_RATIO = 0.60f

    private const val MIN_BRIGHTNESS = 60
    private const val MIN_SATURATION = 45

    private const val MIN_SPAN = 6
    private const val MAX_CANDLE_WIDTH = 28

    private const val MIN_SEQUENCE = 1
    private const val MAX_SPACING_RATIO = 0.45f
    private const val MAX_MISSED_CANDLE_GAP = 2.35f

    private const val SR_ZONE_RATIO = 0.08
    private const val STRONG_BODY_RATIO = 0.55
    private const val MIN_BODY_RATIO = 0.25
    private const val CHOP_RANGE_RATIO = 0.18
    private const val LEVEL_BUFFER_RATIO = 0.06
    private const val MIN_TREND_AGREEMENT = 3
    private const val MIN_SCORE_TO_TRADE = 82.0

    data class DetectedCandle(
        val open: Double,
        val high: Double,
        val low: Double,
        val close: Double,
        val bullish: Boolean
    )

    private data class Candidate(
        val candle: DetectedCandle,
        val center: Int,
        val width: Int,
        val span: Int
    )

    private data class StructureState(
        val higherHighs: Int,
        val higherLows: Int,
        val lowerHighs: Int,
        val lowerLows: Int
    )

    fun detectVisibleCandles(
        bitmap: Bitmap
    ): List<DetectedCandle> {
        return detectCandles(bitmap)
    }

    /**
     * Capture-path diagnostic only. It does not generate a trade signal.
     * This tells us whether MediaProjection is actually delivering the
     * red/green Quotex pixels to the analyzer.
     */
    fun captureDiagnostic(bitmap: Bitmap): String {
        val w = bitmap.width
        val h = bitmap.height
        if (w <= 0 || h <= 0) return "FRAME ${w}x${h} PIXELS:0"

        val top = (h * 0.05f).toInt().coerceIn(0, h - 1)
        val bottom = (h * 0.78f).toInt().coerceIn(top + 1, h)
        val right = (w * 0.94f).toInt().coerceIn(1, w - 1)
        var green = 0
        var red = 0
        var broad = 0

        // Sample every 2nd pixel to keep the diagnostic lightweight.
        var y = top
        while (y < bottom) {
            var x = 0
            while (x < right) {
                val p = bitmap.getPixel(x, y)
                val r = Color.red(p)
                val g = Color.green(p)
                val b = Color.blue(p)
                val maxC = max(r, max(g, b))
                val minC = min(r, min(g, b))
                val sat = maxC - minC
                if (g >= 45 && g > r + 20 && g > b + 8 && sat >= 25) green++
                if (r >= 45 && r > g + 20 && r > b + 8 && sat >= 25) red++
                if (sat >= 25 && maxC >= 45) broad++
                x += 2
            }
            y += 2
        }

        return "FRAME ${w}x${h} G:$green R:$red COLOR:$broad"
    }

    fun analyze(
        bitmap: Bitmap,
        timeframe: String
    ): AnalysisResult {

        val tf = normalizeTimeframe(timeframe)
        val detected = detectCandles(bitmap)

        if (detected.size < MIN_CANDLES + 1) {
            return waitingResult(tf)
        }

        val completed =
            detected
                .dropLast(1)
                .takeLast(MAX_CANDLES)

        if (completed.size < MIN_CANDLES) {
            return waitingResult(tf)
        }

        return analyzeCandles(completed, tf)
    }

    fun analyzeHistory(
        history: List<DetectedCandle>,
        timeframe: String
    ): AnalysisResult {

        val tf = normalizeTimeframe(timeframe)

        if (history.size < MIN_CANDLES) {
            return waitingResult(tf)
        }

        return analyzeCandles(
            history.takeLast(MAX_CANDLES),
            tf
        )
    }

    private fun analyzeCandles(
        candles: List<DetectedCandle>,
        tf: String
    ): AnalysisResult {
        if (candles.size < 25) return waitingResult(tf)

        // ========================================================
        // V9 ADAPTIVE SIGNAL ENGINE
        // Breakout + Pullback/Retest + Reversal
        //
        // The running candle is never supplied here by CaptureService.
        // This function therefore works only with completed candles.
        // ========================================================

        val recent = candles.takeLast(min(80, candles.size))
        val last = recent.last()
        val prev = recent.getOrNull(recent.lastIndex - 1)
        val closes = recent.map { it.close }

        val ema9 = ema(closes, 9)
        val ema21 = ema(closes, 21)
        val rsi14 = rsi(closes, 14)
        val atr14 = atr(recent, 14)
        val adx14 = adx(recent, 14)
        val stochK = stochastic(recent, 5, 3, 3)
        val previousStochK = if (recent.size >= 2) {
            stochastic(recent.dropLast(1), 5, 3, 3)
        } else stochK
        val previousRsi14 = if (recent.size >= 16) {
            rsi(recent.dropLast(1).map { it.close }, 14)
        } else rsi14

        if (!ema9.isFinite() || !ema21.isFinite() || !atr14.isFinite() || atr14 <= 0.0) {
            return waitingResult(tf)
        }

        val body = abs(last.close - last.open)
        val range = (last.high - last.low).coerceAtLeast(atr14 * 0.01)
        val bodyRatioNow = (body / range).coerceIn(0.0, 1.0)
        val closeLocation = ((last.close - last.low) / range).coerceIn(0.0, 1.0)

        // Recent structure only. Never use a 50+ candle breakout level.
        val levelWindow = recent.dropLast(1).takeLast(12)
        if (levelWindow.size < 8) return waitingResult(tf)

        val resistance = levelWindow.maxOf { it.high }
        val support = levelWindow.minOf { it.low }
        val buffer = max(atr14 * 0.08, abs(last.close) * 0.00003)

        val priorWindow = levelWindow.dropLast(2).takeLast(8)
        val priorResistance = if (priorWindow.size >= 5) priorWindow.maxOf { it.high } else resistance
        val priorSupport = if (priorWindow.size >= 5) priorWindow.minOf { it.low } else support

        val structure = calculateStructure(recent.takeLast(12))
        val structureBull = structure.higherHighs + structure.higherLows >
            structure.lowerHighs + structure.lowerLows
        val structureBear = structure.lowerHighs + structure.lowerLows >
            structure.higherHighs + structure.higherLows

        val bullishTrend = ema9 > ema21 && rsi14 >= 52.0 && adx14 >= 17.0 && (structureBull || rsi14 >= 56.0)
        val bearishTrend = ema9 < ema21 && rsi14 <= 48.0 && adx14 >= 17.0 && (structureBear || rsi14 <= 44.0)

        val stochBullish = stochK >= 45.0 && stochK <= 88.0 && stochK > previousStochK
        val stochBearish = stochK <= 55.0 && stochK >= 12.0 && stochK < previousStochK

        // --------------------------------------------------------
        // 1) BREAKOUT — genuine close outside recent structure
        // --------------------------------------------------------
        val bullBreakout =
            last.close > resistance + buffer &&
            last.open <= resistance + buffer * 0.50 &&
            last.bullish &&
            bodyRatioNow >= 0.50 &&
            closeLocation >= 0.68

        val bearBreakout =
            last.close < support - buffer &&
            last.open >= support - buffer * 0.50 &&
            !last.bullish &&
            bodyRatioNow >= 0.50 &&
            closeLocation <= 0.32

        // --------------------------------------------------------
        // 2) PULLBACK / RETEST — continuation after a break
        // --------------------------------------------------------
        val bullRetest =
            prev != null &&
            prev.close > priorResistance + buffer * 0.50 &&
            last.low <= priorResistance + buffer * 0.45 &&
            last.close > priorResistance + buffer * 0.20 &&
            last.bullish &&
            bodyRatioNow >= 0.30 &&
            closeLocation >= 0.55

        val bearRetest =
            prev != null &&
            prev.close < priorSupport - buffer * 0.50 &&
            last.high >= priorSupport - buffer * 0.45 &&
            last.close < priorSupport - buffer * 0.20 &&
            !last.bullish &&
            bodyRatioNow >= 0.30 &&
            closeLocation <= 0.45

        // --------------------------------------------------------
        // 3) REVERSAL — level rejection + momentum change
        // --------------------------------------------------------
        val nearSupport = last.low <= support + atr14 * 0.20
        val nearResistance = last.high >= resistance - atr14 * 0.20

        // Reversal must be a genuine turn, not just one opposite candle.
        // Require level rejection/engulfing + stochastic turn + RSI turn.
        val bullishRejection =
            isBullishRejection(last) || isBullishEngulfing(recent) || isMorningStar(recent)
        val bearishRejection =
            isBearishRejection(last) || isBearishEngulfing(recent) || isEveningStar(recent)

        val bullMomentumTurn =
            stochK > previousStochK + 3.0 &&
            rsi14 >= 45.0 &&
            rsi14 > previousRsi14

        val bearMomentumTurn =
            stochK < previousStochK - 3.0 &&
            rsi14 <= 55.0 &&
            rsi14 < previousRsi14

        val bullReversal =
            nearSupport &&
            bullishRejection &&
            bullMomentumTurn &&
            last.close > last.open &&
            closeLocation >= 0.55

        val bearReversal =
            nearResistance &&
            bearishRejection &&
            bearMomentumTurn &&
            last.close < last.open &&
            closeLocation <= 0.45

        // --------------------------------------------------------
        // Fake-break protection and market regime filter
        // --------------------------------------------------------
        val falseBull = isFalseBullishBreakout(recent)
        val falseBear = isFalseBearishBreakdown(recent)

        val chopWindow = recent.takeLast(10)
        var flips = 0
        var previousDirection = 0
        for (i in 1 until chopWindow.size) {
            val direction = when {
                chopWindow[i].close > chopWindow[i - 1].close -> 1
                chopWindow[i].close < chopWindow[i - 1].close -> -1
                else -> 0
            }
            if (direction != 0 && previousDirection != 0 && direction != previousDirection) flips++
            if (direction != 0) previousDirection = direction
        }

        val rangeSize = resistance - support
        val chop = flips >= 7 || rangeSize <= atr14 * 1.15

        // Range mode: frequent back-and-forth movement inside a bounded
        // recent structure. Only the boundaries are tradable; the middle
        // of the range remains NO TRADE.
        val preliminaryRangeMarket =
            flips >= 4 &&
            rangeSize <= atr14 * 4.0

        val extension = abs(last.close - ema21) / atr14
        val notOverextended = extension <= 1.35

        val resistanceTouches = levelWindow.count { abs(it.high - resistance) <= atr14 * 0.12 }
        val supportTouches = levelWindow.count { abs(it.low - support) <= atr14 * 0.12 }
        val meaningfulResistance = resistanceTouches >= 2
        val meaningfulSupport = supportTouches >= 2

        val rangeMarket =
            preliminaryRangeMarket &&
            meaningfulResistance &&
            meaningfulSupport

        // --------------------------------------------------------
        // Setup scores. Score is QUALITY, not probability of winning.
        // A signal must pass the hard filters below before confidence
        // is converted into a CALL/PUT.
        // --------------------------------------------------------
        var bullScore = 0.0
        var bearScore = 0.0

        if (bullBreakout) bullScore += 32.0
        if (bullRetest) bullScore += 34.0
        if (bullReversal) bullScore += 34.0
        if (bullishTrend) bullScore += 16.0
        if (structureBull) bullScore += 10.0
        if (adx14 >= 22.0) bullScore += 8.0
        if (rsi14 in 52.0..68.0) bullScore += 6.0
        if (stochBullish) bullScore += 7.0
        if (bodyRatioNow >= 0.55) bullScore += 6.0
        if (meaningfulResistance) bullScore += 5.0

        if (bearBreakout) bearScore += 32.0
        if (bearRetest) bearScore += 34.0
        if (bearReversal) bearScore += 34.0
        if (bearishTrend) bearScore += 16.0
        if (structureBear) bearScore += 10.0
        if (adx14 >= 22.0) bearScore += 8.0
        if (rsi14 in 32.0..48.0) bearScore += 6.0
        if (stochBearish) bearScore += 7.0
        if (bodyRatioNow >= 0.55) bearScore += 6.0
        if (meaningfulSupport) bearScore += 5.0

        if (falseBull) bullScore -= 30.0
        if (falseBear) bearScore -= 30.0
        if (chop) {
            bullScore -= 30.0
            bearScore -= 30.0
        }
        if (!notOverextended) {
            bullScore -= 18.0
            bearScore -= 18.0
        }

        bullScore = bullScore.coerceIn(0.0, 100.0)
        bearScore = bearScore.coerceIn(0.0, 100.0)

        val bullSetup = bullBreakout || bullRetest || bullReversal
        val bearSetup = bearBreakout || bearRetest || bearReversal

        // A setup needs at least three independent confirmations.
        val bullConfirmations = listOf(
            bullishTrend,
            structureBull,
            stochBullish,
            adx14 >= 17.0,
            bodyRatioNow >= 0.30,
            meaningfulResistance || bullReversal
        ).count { it }

        val bearConfirmations = listOf(
            bearishTrend,
            structureBear,
            stochBearish,
            adx14 >= 17.0,
            bodyRatioNow >= 0.30,
            meaningfulSupport || bearReversal
        ).count { it }

        // In a range, only a confirmed boundary reversal may bypass the
        // normal trend/chop block. Breakouts and pullbacks still need the
        // normal non-choppy regime.
        val bullRangeReversal = rangeMarket && bullReversal && !bearReversal
        val bearRangeReversal = rangeMarket && bearReversal && !bullReversal

        val callSetup =
            bullSetup &&
            !bearSetup &&
            (!chop || bullRangeReversal) &&
            !falseBull &&
            notOverextended &&
            bullConfirmations >= 4 &&
            bullScore >= 78.0 &&
            bullScore > bearScore + 15.0

        val putSetup =
            bearSetup &&
            !bullSetup &&
            (!chop || bearRangeReversal) &&
            !falseBear &&
            notOverextended &&
            bearConfirmations >= 4 &&
            bearScore >= 78.0 &&
            bearScore > bullScore + 15.0

        // Confidence is setup quality, not a win-rate claim.
        // Only strong setups reach the app's existing 90% trade gate.
        val confidence = when {
            callSetup -> (88.0 + bullScore * 0.075 + (bullConfirmations - 4) * 1.5)
                .roundToInt().coerceIn(90, 96)
            putSetup -> (88.0 + bearScore * 0.075 + (bearConfirmations - 4) * 1.5)
                .roundToInt().coerceIn(90, 96)
            else -> 0
        }

        if (callSetup && confidence >= 90) {
            val setupName = when {
                bullReversal -> "BULLISH REVERSAL"
                bullRetest -> "BULLISH PULLBACK"
                else -> "BULLISH BREAKOUT"
            }
            return AnalysisResult(tf, setupName, "CALL", confidence,
                bullScore.roundToInt(), bearScore.roundToInt())
        }

        if (putSetup && confidence >= 90) {
            val setupName = when {
                bearReversal -> "BEARISH REVERSAL"
                bearRetest -> "BEARISH PULLBACK"
                else -> "BEARISH BREAKOUT"
            }
            return AnalysisResult(tf, setupName, "PUT", confidence,
                bullScore.roundToInt(), bearScore.roundToInt())
        }

        val trend = when {
            rangeMarket && nearSupport -> "RANGE / SUPPORT"
            rangeMarket && nearResistance -> "RANGE / RESISTANCE"
            rangeMarket -> "RANGE / WAIT BOUNDARY"
            bullishTrend && bullScore > bearScore + 10.0 -> "BULLISH / WAIT SETUP"
            bearishTrend && bearScore > bullScore + 10.0 -> "BEARISH / WAIT SETUP"
            else -> "SIDEWAYS / WAIT SETUP"
        }

        return AnalysisResult(tf, trend, "NO TRADE", 0,
            bullScore.roundToInt(), bearScore.roundToInt())
    }

    private fun ema(values: List<Double>, period: Int): Double {
        if (values.isEmpty()) return Double.NaN
        val p = period.coerceAtLeast(2)
        val start = max(0, values.size - max(p * 3, p))
        var result = values[start]
        val alpha = 2.0 / (p + 1.0)
        for (i in start + 1 until values.size) {
            result = alpha * values[i] + (1.0 - alpha) * result
        }
        return result
    }

    private fun rsi(values: List<Double>, period: Int): Double {
        if (values.size <= period) return Double.NaN
        var gains = 0.0
        var losses = 0.0
        val start = values.size - period
        for (i in start until values.size) {
            val change = values[i] - values[i - 1]
            if (change >= 0) gains += change else losses -= change
        }
        if (losses == 0.0) return 100.0
        val rs = gains / losses
        return 100.0 - (100.0 / (1.0 + rs))
    }

    private fun atr(candles: List<DetectedCandle>, period: Int): Double {
        if (candles.size < 2) return Double.NaN
        val trs = mutableListOf<Double>()
        for (i in 1 until candles.size) {
            val c = candles[i]
            val p = candles[i - 1]
            trs += max(c.high - c.low, max(abs(c.high - p.close), abs(c.low - p.close)))
        }
        return trs.takeLast(min(period, trs.size)).average()
    }

    private fun adx(candles: List<DetectedCandle>, period: Int): Double {
        if (candles.size < period + 2) return 0.0
        val tr = mutableListOf<Double>()
        val plusDm = mutableListOf<Double>()
        val minusDm = mutableListOf<Double>()
        for (i in 1 until candles.size) {
            val c = candles[i]
            val p = candles[i - 1]
            val up = c.high - p.high
            val down = p.low - c.low
            plusDm += if (up > down && up > 0) up else 0.0
            minusDm += if (down > up && down > 0) down else 0.0
            tr += max(c.high - c.low, max(abs(c.high - p.close), abs(c.low - p.close)))
        }
        val n = min(period, tr.size)
        if (n < period) return 0.0
        val trSum = tr.takeLast(n).sum()
        if (trSum <= 0.0) return 0.0
        val plusDi = 100.0 * plusDm.takeLast(n).sum() / trSum
        val minusDi = 100.0 * minusDm.takeLast(n).sum() / trSum
        val denom = plusDi + minusDi
        if (denom <= 0.0) return 0.0
        return 100.0 * abs(plusDi - minusDi) / denom
    }

    private fun stochastic(candles: List<DetectedCandle>, period: Int, smoothK: Int, smoothD: Int): Double {
        if (candles.size < period) return 50.0
        val ks = mutableListOf<Double>()
        val start = max(period - 1, candles.size - 6)
        for (i in start until candles.size) {
            val window = candles.subList(i - period + 1, i + 1)
            val high = window.maxOf { it.high }
            val low = window.minOf { it.low }
            val denom = high - low
            ks += if (denom <= 0.0) 50.0 else ((candles[i].close - low) / denom) * 100.0
        }
        return ks.takeLast(min(smoothK, ks.size)).average()
    }

    // ============================================================
    // STRUCTURE
    // ============================================================

    private fun calculateStructure(
        candles: List<DetectedCandle>
    ): StructureState {

        var higherHighs = 0
        var higherLows = 0
        var lowerHighs = 0
        var lowerLows = 0

        for (i in 2 until candles.size) {

            val a = candles[i - 2]
            val b = candles[i - 1]
            val c = candles[i]

            if (
                b.high > a.high &&
                c.high > b.high
            ) {
                higherHighs++
            }

            if (
                b.low > a.low &&
                c.low > b.low
            ) {
                higherLows++
            }

            if (
                b.high < a.high &&
                c.high < b.high
            ) {
                lowerHighs++
            }

            if (
                b.low < a.low &&
                c.low < b.low
            ) {
                lowerLows++
            }
        }

        return StructureState(
            higherHighs,
            higherLows,
            lowerHighs,
            lowerLows
        )
    }

    // ============================================================
    // TREND
    // ============================================================

    private fun directionalTrend(
        bull: Int,
        bear: Int,
        bullishMA: Boolean,
        bearishMA: Boolean,
        bullishStructure: Boolean,
        bearishStructure: Boolean
    ): String {

        return when {

            bull > bear &&
            bullishMA ->
                "BULLISH"

            bear > bull &&
            bearishMA ->
                "BEARISH"

            bullishStructure &&
            !bearishStructure ->
                "BULLISH"

            bearishStructure &&
            !bullishStructure ->
                "BEARISH"

            else ->
                "SIDEWAYS"
        }
    }

    // ============================================================
    // BODY RATIO
    // ============================================================

    private fun bodyRatio(
        candle: DetectedCandle
    ): Double {

        val totalRange =
            candle.high - candle.low

        if (
            totalRange <= 0.000001
        ) {
            return 0.0
        }

        val body =
            abs(
                candle.close -
                candle.open
            )

        return (
            body / totalRange
        ).coerceIn(
            0.0,
            1.0
        )
    }

    // ============================================================
    // BULLISH RETEST
    // ============================================================

    private fun isBullishRetest(
        candles: List<DetectedCandle>
    ): Boolean {

        if (candles.size < 4) {
            return false
        }

        val a =
            candles[candles.lastIndex - 3]

        val b =
            candles[candles.lastIndex - 2]

        val c =
            candles[candles.lastIndex - 1]

        val d =
            candles.last()

        val breakoutUp =
            b.close > a.high

        val retest =
            c.low <= b.close ||
            c.low <= b.high

        val recovery =
            d.bullish &&
            d.close > c.close

        return breakoutUp &&
            retest &&
            recovery
    }

    // ============================================================
    // BEARISH RETEST
    // ============================================================

    private fun isBearishRetest(
        candles: List<DetectedCandle>
    ): Boolean {

        if (candles.size < 4) {
            return false
        }

        val a =
            candles[candles.lastIndex - 3]

        val b =
            candles[candles.lastIndex - 2]

        val c =
            candles[candles.lastIndex - 1]

        val d =
            candles.last()

        val breakoutDown =
            b.close < a.low

        val retest =
            c.high >= b.close ||
            c.high >= b.low

        val recovery =
            !d.bullish &&
            d.close < c.close

        return breakoutDown &&
            retest &&
            recovery
    }

    // ============================================================
    // FALSE BULLISH BREAKOUT
    // ============================================================

    private fun isFalseBullishBreakout(
        candles: List<DetectedCandle>
    ): Boolean {

        if (candles.size < 3) {
            return false
        }

        val previous =
            candles.dropLast(1)

        val resistance =
            previous
                .takeLast(
                    min(8, previous.size)
                )
                .maxOf {
                    it.high
                }

        val current =
            candles.last()

        val brokeAbove =
            current.high > resistance

        val closedBackInside =
            current.close < resistance

        return brokeAbove &&
            closedBackInside &&
            !current.bullish
    }

    // ============================================================
    // FALSE BEARISH BREAKDOWN
    // ============================================================

    private fun isFalseBearishBreakdown(
        candles: List<DetectedCandle>
    ): Boolean {

        if (candles.size < 3) {
            return false
        }

        val previous =
            candles.dropLast(1)

        val support =
            previous
                .takeLast(
                    min(8, previous.size)
                )
                .minOf {
                    it.low
                }

        val current =
            candles.last()

        val brokeBelow =
            current.low < support

        val closedBackInside =
            current.close > support

        return brokeBelow &&
            closedBackInside &&
            current.bullish
    }

    // ============================================================
    // BULLISH ENGULFING
    // ============================================================

    private fun isBullishEngulfing(
        candles: List<DetectedCandle>
    ): Boolean {

        if (candles.size < 2) {
            return false
        }

        val previous =
            candles[candles.lastIndex - 1]

        val current =
            candles.last()

        return !previous.bullish &&
            current.bullish &&
            current.open <= previous.close &&
            current.close >= previous.open &&
            bodyRatio(current) >= 0.40
    }

    // ============================================================
    // BEARISH ENGULFING
    // ============================================================

    private fun isBearishEngulfing(
        candles: List<DetectedCandle>
    ): Boolean {

        if (candles.size < 2) {
            return false
        }

        val previous =
            candles[candles.lastIndex - 1]

        val current =
            candles.last()

        return previous.bullish &&
            !current.bullish &&
            current.open >= previous.close &&
            current.close <= previous.open &&
            bodyRatio(current) >= 0.40
    }

    // ============================================================
    // MORNING STAR
    // ============================================================

    private fun isMorningStar(
        candles: List<DetectedCandle>
    ): Boolean {

        if (candles.size < 3) {
            return false
        }

        val a =
            candles[candles.size - 3]

        val b =
            candles[candles.size - 2]

        val c =
            candles.last()

        val aBody =
            abs(a.close - a.open)

        val bBody =
            abs(b.close - b.open)

        val cBody =
            abs(c.close - c.open)

        if (aBody <= 0.000001) {
            return false
        }

        return !a.bullish &&
            bBody <= aBody * 0.55 &&
            c.bullish &&
            cBody >= aBody * 0.55 &&
            c.close >
            (a.open + a.close) / 2.0
    }

    // ============================================================
    // EVENING STAR
    // ============================================================

    private fun isEveningStar(
        candles: List<DetectedCandle>
    ): Boolean {

        if (candles.size < 3) {
            return false
        }

        val a =
            candles[candles.size - 3]

        val b =
            candles[candles.size - 2]

        val c =
            candles.last()

        val aBody =
            abs(a.close - a.open)

        val bBody =
            abs(b.close - b.open)

        val cBody =
            abs(c.close - c.open)

        if (aBody <= 0.000001) {
            return false
        }

        return a.bullish &&
            bBody <= aBody * 0.55 &&
            !c.bullish &&
            cBody >= aBody * 0.55 &&
            c.close <
            (a.open + a.close) / 2.0
    }

    // ============================================================
    // BULLISH REJECTION
    // ============================================================

    private fun isBullishRejection(
        candle: DetectedCandle
    ): Boolean {

        val body =
            abs(
                candle.close -
                candle.open
            )

        val safeBody =
            max(body, 0.000001)

        val lowerWick =
            min(
                candle.open,
                candle.close
            ) -
            candle.low

        return candle.bullish &&
            lowerWick > safeBody * 1.2
    }

    // ============================================================
    // BEARISH REJECTION
    // ============================================================

    private fun isBearishRejection(
        candle: DetectedCandle
    ): Boolean {

        val body =
            abs(
                candle.close -
                candle.open
            )

        val safeBody =
            max(body, 0.000001)

        val upperWick =
            candle.high -
            max(
                candle.open,
                candle.close
            )

        return !candle.bullish &&
            upperWick > safeBody * 1.2
    }

    // ============================================================
    // GREEN PIXEL
    // ============================================================

    private fun isGreen(pixel: Int): Boolean {
        val r = Color.red(pixel)
        val g = Color.green(pixel)
        val b = Color.blue(pixel)
        val maxC = max(r, max(g, b))
        val minC = min(r, min(g, b))
        val saturation = maxC - minC
        return g >= MIN_BRIGHTNESS &&
            g > r + MIN_SATURATION &&
            g > b + 10 &&
            saturation >= MIN_SATURATION
    }

    // Accept both normal red and a possible R/B-swapped ImageReader frame.
    // The latter can occur on some Android compositor paths. Blue UI pixels
    // are rejected unless they have the same strong red-like separation.
    private fun isRed(pixel: Int): Boolean {
        val r = Color.red(pixel)
        val g = Color.green(pixel)
        val b = Color.blue(pixel)
        val normalRed = r >= MIN_BRIGHTNESS &&
            r > g + MIN_SATURATION &&
            r > b + 10
        val swappedRed = b >= MIN_BRIGHTNESS &&
            b > g + MIN_SATURATION &&
            b > r + 10
        val maxC = max(r, max(g, b))
        val minC = min(r, min(g, b))
        return (normalRed || swappedRed) && maxC - minC >= MIN_SATURATION
    }

    private fun isCandlePixel(pixel: Int): Boolean {
        return isGreen(pixel) || isRed(pixel)
    }

    // ============================================================
    // TIMEFRAME
    // ============================================================

    // ============================================================

    private fun normalizeTimeframe(
        timeframe: String
    ): String {

        return when (
            timeframe.trim().uppercase()
        ) {

            "5M",
            "5 MIN",
            "5MIN",
            "5 MINUTE" ->
                "5M"

            "15M",
            "15 MIN",
            "15MIN",
            "15 MINUTE" ->
                "15M"

            else ->
                "1M"
        }
    }

    // ============================================================
    // WAITING
    // ============================================================

    private fun waitingResult(
        timeframe: String
    ): AnalysisResult {

        return AnalysisResult(
            timeframe = timeframe,
            trend = "WAITING",
            signal = "NO TRADE",
            confidence = 0,
            bullishScore = 0,
            bearishScore = 0
        )
    }

    // ============================================================
    // DETECT CANDLES
    // ============================================================

    private fun detectCandles(
        bitmap: Bitmap
    ): List<DetectedCandle> {
        val width = bitmap.width
        val height = bitmap.height
        if (width < 200 || height < 300) return emptyList()

        // V11: use the actual Quotex chart area rather than the whole frame.
        // On the target phone the candles sit roughly in the middle 55% of
        // the screen. The top overlay/buttons are deliberately excluded.
        // V14: use a wider adaptive chart ROI. Different phones/Quotex layouts place
        // the chart at different vertical positions; the old 8%-70% window could
        // exclude most of the candles and correctly produce CANDLES: 0.
        val top = (height * 0.03f).toInt().coerceIn(0, height - 2)
        val bottom = (height * 0.92f).toInt().coerceIn(top + 1, height)
        val right = (width * 0.98f).toInt().coerceIn(200, width - 1)

        val greenMask = ArrayList<BooleanArray>(bottom - top)
        val redMask = ArrayList<BooleanArray>(bottom - top)
        val xScore = IntArray(right + 1)

        // Slightly more tolerant than the old detector. Quotex candle colors
        // can be softened by MediaProjection/compositor conversion.
        for (y in top until bottom) {
            val gRow = BooleanArray(right + 1)
            val rRow = BooleanArray(right + 1)
            for (x in 0..right) {
                val p = bitmap.getPixel(x, y)
                val r = Color.red(p)
                val g = Color.green(p)
                val b = Color.blue(p)
                val maxC = max(r, max(g, b))
                val minC = min(r, min(g, b))
                val sat = maxC - minC

                val green = g >= 40 && g > r + 18 && g > b + 6 && sat >= 20
                val red = r >= 40 && r > g + 18 && r > b + 6 && sat >= 20
                gRow[x] = green
                rRow[x] = red
                if (green || red) xScore[x]++
            }
            greenMask += gRow
            redMask += rRow
        }

        if ((xScore.maxOrNull() ?: 0) < 3) return emptyList()

        // A candle normally produces several adjacent colored columns. Group
        // those columns into candle bodies/wicks and reject tiny noise runs.
        val runs = mutableListOf<IntRange>()
        var runStart = -1
        for (x in 0..right) {
            val active = xScore[x] >= 2
            if (active && runStart < 0) {
                runStart = x
            } else if (!active && runStart >= 0) {
                val endX = x - 1
                if (endX - runStart + 1 in 2..36) runs += runStart..endX
                runStart = -1
            }
        }
        if (runStart >= 0) {
            val endX = right
            if (endX - runStart + 1 in 2..36) runs += runStart..endX
        }

        // V12: the x-column runs above can merge several adjacent Quotex candles
        // into one long colored run (especially during strong trends). In that
        // case the old run-width filter rejects the entire chart and returns 0.
        // Use the peak-based detector on the same ROI instead of giving up.
        if (runs.size < MIN_SEQUENCE) {
            return detectCandlesByPeaks(
                bitmap,
                top,
                bottom,
                right
            )
        }

        val candidates = mutableListOf<Pair<Int, DetectedCandle>>()
        for (run in runs) {
            val left = run.first
            val rr = run.last
            var green = 0
            var red = 0
            var highY = bottom
            var lowY = top

            for (x in left..rr) {
                for (yi in top until bottom) {
                    val row = yi - top
                    if (greenMask[row][x]) {
                        green++
                        highY = min(highY, yi)
                        lowY = max(lowY, yi)
                    } else if (redMask[row][x]) {
                        red++
                        highY = min(highY, yi)
                        lowY = max(lowY, yi)
                    }
                }
            }

            val total = green + red
            val span = lowY - highY + 1
            if (total < 6 || span < MIN_SPAN) continue

            val bullish = green >= red
            val rowCounts = IntArray(bottom - top)
            for (x in left..rr) {
                for (yi in top until bottom) {
                    val row = yi - top
                    if (if (bullish) greenMask[row][x] else redMask[row][x]) {
                        rowCounts[row]++
                    }
                }
            }

            val bodyThreshold = max(2, ((rr - left + 1) * 0.30f).roundToInt())
            var bodyTop = bottom
            var bodyBottom = top
            for (i in rowCounts.indices) {
                if (rowCounts[i] >= bodyThreshold) {
                    val y = top + i
                    bodyTop = min(bodyTop, y)
                    bodyBottom = max(bodyBottom, y)
                }
            }

            if (bodyTop >= bodyBottom) {
                bodyTop = highY + max(1, span / 4)
                bodyBottom = lowY - max(1, span / 4)
            }
            if (bodyTop >= bodyBottom) continue

            val high = (bottom - highY).toDouble()
            val low = (bottom - lowY).toDouble()
            val bodyHigh = (bottom - bodyTop).toDouble()
            val bodyLow = (bottom - bodyBottom).toDouble()
            val open = if (bullish) bodyLow else bodyHigh
            val close = if (bullish) bodyHigh else bodyLow

            if (high <= low || open !in low..high || close !in low..high) continue
            candidates += ((left + rr) / 2) to DetectedCandle(open, high, low, close, bullish)
        }

        if (candidates.size < MIN_SEQUENCE) {
            return detectCandlesByPeaks(
                bitmap,
                top,
                bottom,
                right
            )
        }
        return candidates.sortedBy { it.first }.map { it.second }.takeLast(MAX_CANDLES)
    }

    private fun detectCandlesByPeaks(
        bitmap: Bitmap,
        rawTop: Int,
        rawBottom: Int,
        rawRight: Int
    ): List<DetectedCandle> {

        val width = bitmap.width
        val height = bitmap.height
        val top = rawTop.coerceIn(0, height - 2)
        val bottom = rawBottom.coerceIn(top + 1, height)
        val right = rawRight.coerceIn(200, width - 1)
        if (bottom - top < 180) return emptyList()

        val xScore = IntArray(right + 1)
        for (x in 0..right) {
            var count = 0
            for (y in top until bottom) {
                val pixel = bitmap.getPixel(x, y)
                if (isCandlePixel(pixel)) count++
            }
            xScore[x] = count
        }

        if ((xScore.maxOrNull() ?: 0) < 4) return emptyList()

        // Quotex candles are narrow on the target phone. Keep a conservative
        // minimum distance so a wick/body cannot create two candles.
        val estimatedSpacing = (width / 75.0).roundToInt().coerceIn(8, 20)
        val minPeakDistance = max(8, (estimatedSpacing * 0.75f).roundToInt())
        val rawPeaks = mutableListOf<Int>()

        for (x in 1 until right) {
            if (xScore[x] < 4) continue
            if (xScore[x] >= xScore[x - 1] && xScore[x] >= xScore[x + 1]) {
                rawPeaks += x
            }
        }

        if (rawPeaks.isEmpty()) return emptyList()

        // Collapse nearby maxima, retaining the strongest one.
        val centers = mutableListOf<Int>()
        for (peak in rawPeaks) {
            if (centers.isEmpty()) {
                centers += peak
            } else {
                val lastIndex = centers.lastIndex
                val last = centers[lastIndex]
                if (peak - last < minPeakDistance) {
                    if (xScore[peak] > xScore[last]) centers[lastIndex] = peak
                } else {
                    centers += peak
                }
            }
        }

        if (centers.size < MIN_SEQUENCE) return emptyList()

        val halfWidth = max(3, (estimatedSpacing * 0.42f).roundToInt())
        val candidates = mutableListOf<Pair<Int, DetectedCandle>>()

        for (center in centers) {
            val left = (center - halfWidth).coerceAtLeast(0)
            val rr = (center + halfWidth).coerceAtMost(right)

            var green = 0
            var red = 0
            var highY = bottom
            var lowY = top

            for (x in left..rr) {
                for (y in top until bottom) {
                    val pixel = bitmap.getPixel(x, y)
                    if (isGreen(pixel)) {
                        green++
                        highY = min(highY, y)
                        lowY = max(lowY, y)
                    } else if (isRed(pixel)) {
                        red++
                        highY = min(highY, y)
                        lowY = max(lowY, y)
                    }
                }
            }

            val total = green + red
            val span = lowY - highY + 1
            if (total < 8 || span < MIN_SPAN) continue

            val bullish = green >= red
            val rowCounts = IntArray(bottom - top)
            for (x in left..rr) {
                for (y in top until bottom) {
                    val pixel = bitmap.getPixel(x, y)
                    if (if (bullish) isGreen(pixel) else isRed(pixel)) {
                        rowCounts[y - top]++
                    }
                }
            }

            val bodyThreshold = max(2, ((rr - left + 1) * 0.30f).roundToInt())
            var bodyTop = bottom
            var bodyBottom = top
            for (i in rowCounts.indices) {
                if (rowCounts[i] >= bodyThreshold) {
                    val y = top + i
                    bodyTop = min(bodyTop, y)
                    bodyBottom = max(bodyBottom, y)
                }
            }

            if (bodyTop >= bodyBottom) {
                bodyTop = highY + span / 4
                bodyBottom = lowY - span / 4
            }
            if (bodyTop >= bodyBottom) continue

            val high = (bottom - highY).toDouble()
            val low = (bottom - lowY).toDouble()
            val bodyHigh = (bottom - bodyTop).toDouble()
            val bodyLow = (bottom - bodyBottom).toDouble()
            val open = if (bullish) bodyLow else bodyHigh
            val close = if (bullish) bodyHigh else bodyLow

            if (high <= low || open !in low..high || close !in low..high) continue

            candidates += center to DetectedCandle(
                open,
                high,
                low,
                close,
                bullish
            )
        }

        if (candidates.size < MIN_SEQUENCE) return emptyList()

        return candidates
            .sortedBy { it.first }
            .map { it.second }
            .takeLast(MAX_CANDLES)
    }


}
