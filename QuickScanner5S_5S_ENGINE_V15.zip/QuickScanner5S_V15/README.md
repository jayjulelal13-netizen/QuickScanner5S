# QuickScanner5S V15

Fresh 5-second candle-engine build based on the existing QuickScanner5S project.

## V15 changes
- Reworked candle detection around the actual Quotex chart plot region.
- Excludes the top deposit/status UI and bottom Up/Down trading controls from candle detection.
- Uses adaptive vertical color-density peaks instead of merged x-runs.
- Keeps the existing MediaProjection capture and 5S quick engine.
- Keeps signal generation demo-only; it does not place broker orders.
- CALL/PUT is gated by the existing confidence/calibration logic.

## Build
GitHub Actions workflow builds `app-debug.apk` with JDK 17 and Android API 35.
