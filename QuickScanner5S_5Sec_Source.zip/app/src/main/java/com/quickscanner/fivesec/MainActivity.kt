package com.quickscanner.fivesec

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var candle: TextView
    private lateinit var signal: TextView
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        startDemoEngine()
    }

    private fun buildUi() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 12, 18, 12)
            setBackgroundColor(Color.argb(235, 0, 0, 0))
        }
        candle = tv("5 SEC  •  CANDLE: SCANNING")
        signal = tv("SIGNAL: WAIT")
        status = tv("STATUS: —")
        box.addView(candle)
        box.addView(signal)
        box.addView(status)
        setContentView(box)
    }

    private fun tv(text: String) = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, 3, 0, 3)
    }

    private fun startDemoEngine() {
        // Safe placeholder: no fake market signal is generated.
        // Real 5-second candle detection must be connected to the chart capture pipeline.
        candle.postDelayed(object : Runnable {
            override fun run() {
                candle.text = "5 SEC  •  CANDLE: WAITING"
                signal.text = "SIGNAL: NO TRADE"
                status.text = "STATUS: —"
                candle.postDelayed(this, 1000)
            }
        }, 1000)
    }
}
