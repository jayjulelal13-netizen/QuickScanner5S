# QuickScanner5S — Quotex 5S

Set the Quotex chart itself to 5 seconds before starting screen capture.

- Reads visible chart candles through MediaProjection.
- Uses the rightmost detected candle as running; analyzes only completed 5S candles.
- Never converts a 1-minute candle into a fake 5-second candle.
- No seeded/fake probability.
- CALL/PUT requires analyzer confidence >= 90.
- WIN/LOSS is settled from the exact completed target candle.
- No broker order placement.
