# QuickScanner5S

Dedicated second Android app for 5-second quick scanning.

- Package: `com.example.quickscanner`
- Existing BinomoScreener app is not modified.
- Uses MediaProjection live screen frames.
- If the broker has no native 5-second candle, the app derives a 5-second bucket from successive visible chart frames.
- The 5S engine is updated on every valid captured frame.
- CALL/PUT requires 90%+ setup confidence.
- No fake historical 90% win-rate is seeded.
- Demo only; it does not place broker orders.
- Keep the chart visible while capture is running.
