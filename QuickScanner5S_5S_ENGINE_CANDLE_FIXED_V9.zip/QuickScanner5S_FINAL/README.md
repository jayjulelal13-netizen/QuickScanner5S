# QuickScanner5S

Dedicated 5-second Binomo screen scanner.

Flow:
Binomo 5S chart -> MediaProjection -> visible candle detection -> completed 5S candle history -> CALL/PUT setup -> next 5S candle result.

The overlay is intentionally minimal: candle count, signal/confidence, status and result. No Entry/Exit display.

Important: the app must be granted screen-capture permission and the Binomo 5S chart must remain visible while scanning.


V6: adaptive vertical chart-region scanning for Quotex candle detection.
