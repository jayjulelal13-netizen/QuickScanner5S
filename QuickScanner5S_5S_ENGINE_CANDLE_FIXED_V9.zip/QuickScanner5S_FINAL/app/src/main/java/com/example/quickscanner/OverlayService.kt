package com.example.quickscanner

import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class OverlayService : Service() {

    companion object {
        private const val ACTION_FRAME_STATUS = "com.example.quickscanner.FRAME_STATUS"
        const val ACTION_HIDE_OVERLAY = "com.example.quickscanner.HIDE_OVERLAY"
        private const val CONFIDENCE_LEVEL = 90
    }

    private lateinit var windowManager: WindowManager
    private var overlayView: TextView? = null
    private var receiverRegistered = false

    private var timeframe = "5S"
    private var nextSignal = "NO TRADE"
    private var nextConfidence = 0
    private var nextProbabilitySamples = 0
    private var nextTrend = "WAITING"
    private var signalLocked = false

    private var activeSignal = "NONE"
    private var activeConfidence = 0
    private var activeEntry = Double.NaN
    private var activeTrade = false

    private var lastEntry = Double.NaN
    private var lastExit = Double.NaN
    private var lastResult = "NONE"
    private var lastResultSignal = "NONE"

    private var status = "SCANNING"
    private var candleCount = 0

    private var quickSignal = "NO TRADE"
    private var quickProbability = 0
    private var quickSamples = 0
    private var quickStatus = "WAITING"

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != ACTION_FRAME_STATUS) return

            timeframe = intent.getStringExtra("timeframe") ?: timeframe

            if (intent.hasExtra("count")) {
                candleCount = intent.getIntExtra("count", candleCount)
            }

            when (intent.getStringExtra("status")) {
                "CAPTURE_DIAGNOSTIC" -> {
                    status = intent.getStringExtra("diagnostic") ?: "CAPTURE DIAGNOSTIC"
                    updateOverlay()
                }

                "CAPTURE_STARTED" -> {
                    resetState()
                    timeframe = intent.getStringExtra("timeframe") ?: "5S"
                    status = "SCANNING"
                    ensureOverlay()
                    updateOverlay()
                }

                "CHART_NOT_DETECTED" -> {
                    nextSignal = "NO TRADE"
                    nextConfidence = 0
                    nextTrend = "WAITING"
                    signalLocked = false
                    status = "CHART NOT DETECTED"
                    updateOverlay()
                }

                "PROJECTION_STARTING", "IMAGE_READER_CREATED", "VIRTUAL_DISPLAY_CREATED",
                "FRAME_READY", "CANDLES_DETECTED", "CANDLE_DETECTION_WAITING", "HISTORY_WAITING",
                "NO_CHART_WAITING",
                "LIVE_ANALYSIS", "CANDLE_RUNNING", "CANDLE_WAITING", "WAITING_NEW_CANDLE",
                "RESULT_WAITING_CANDLE_CONFIRMATION", "ANALYSIS_ERROR", "FRAME_ERROR" -> {
                    if (intent.getStringExtra("status") == "NO_CHART_WAITING" ||
                        intent.getStringExtra("status") == "CANDLE_DETECTION_WAITING" ||
                        intent.getStringExtra("status") == "HISTORY_WAITING") {
                        nextSignal = "NO TRADE"
                        nextConfidence = 0
                        nextTrend = "WAITING"
                        signalLocked = false
                        if (!activeTrade) status = "NO CHART / WAITING"
                        updateOverlay()
                        return
                    }
                    if (intent.getStringExtra("status") == "LIVE_ANALYSIS" &&
                        !activeTrade && !signalLocked
                    ) {
                        val liveSignal = intent.getStringExtra("signal")?.uppercase(Locale.US) ?: "NO TRADE"
                        nextConfidence = if (liveSignal == "CALL" || liveSignal == "PUT") {
                            intent.getIntExtra("probability", intent.getIntExtra("confidence", 0))
                        } else {
                            0
                        }
                        nextProbabilitySamples =
                            intent.getIntExtra("probabilitySamples", 0)
                        nextTrend = intent.getStringExtra("trend") ?: nextTrend
                    }

                    if (!activeTrade && !signalLocked) status = "SCANNING"
                    if (signalLocked && (nextSignal == "CALL" || nextSignal == "PUT")) {
                        status = "SIGNAL LOCKED"
                    }
                    updateOverlay()
                }

                "QUICK_5S" -> {
                    quickSignal =
                        intent.getStringExtra("quickSignal")
                            ?.uppercase(Locale.US)
                            ?: "NO TRADE"
                    quickProbability =
                        intent.getIntExtra("quickProbability", 0)
                    quickSamples =
                        intent.getIntExtra("quickSamples", 0)
                    quickStatus =
                        intent.getStringExtra("quickStatus")
                            ?: "WAITING"
                    updateOverlay()
                }

                "ANALYSIS_READY" -> {
                    val signal = intent.getStringExtra("signal")?.uppercase(Locale.US) ?: "NO TRADE"
                    val confidence = intent.getIntExtra("probability", intent.getIntExtra("confidence", 0))
                    val probabilitySamples =
                        intent.getIntExtra("probabilitySamples", 0)
                    val trend = intent.getStringExtra("trend") ?: "UNKNOWN"

                    if ((signal == "CALL" || signal == "PUT") && confidence >= CONFIDENCE_LEVEL) {
                        nextSignal = signal
                        nextConfidence = confidence
                        nextProbabilitySamples = probabilitySamples
                        nextTrend = trend
                        signalLocked = true
                        status = "SIGNAL LOCKED"
                    } else {
                        nextSignal = "NO TRADE"
                        nextProbabilitySamples = probabilitySamples
                        // Keep the analyzer's real setup strength visible.
                        // A chart is present, so NO TRADE does not mean 0%.
                        nextConfidence = 0
                        nextTrend = trend
                        signalLocked = false
                        status = "NO TRADE"
                    }
                    updateOverlay()
                }

                "TRADE_ENTRY" -> {
                    val signal = intent.getStringExtra("signal")?.uppercase(Locale.US) ?: "NO TRADE"
                    if (signal != "CALL" && signal != "PUT") return

                    activeSignal = signal
                    activeConfidence = intent.getIntExtra("confidence", nextConfidence)
                    activeEntry = intent.getDoubleExtra("entryPrice", Double.NaN)
                    lastEntry = activeEntry
                    activeTrade = true

                    nextSignal = "NO TRADE"
                    nextConfidence = 0
                    nextTrend = "WAITING"
                    signalLocked = false
                    status = "TRADE RUNNING"
                    updateOverlay()
                }

                "RESULT_READY" -> {
                    lastResult = intent.getStringExtra("result")?.uppercase(Locale.US) ?: "DRAW"
                    lastResultSignal = intent.getStringExtra("resultSignal")?.uppercase(Locale.US) ?: "NONE"
                    lastEntry = intent.getDoubleExtra("entryPrice", lastEntry)
                    lastExit = intent.getDoubleExtra("exitPrice", Double.NaN)

                    activeTrade = false
                    activeSignal = "NONE"
                    activeConfidence = 0
                    activeEntry = Double.NaN
                    status = "RESULT CONFIRMED"
                    updateOverlay()
                }

                "CAPTURE_STOPPED" -> {
                    removeOverlayNow()
                    resetState()
                }

                "CAPTURE_ERROR", "PROJECTION_ERROR", "VIRTUAL_DISPLAY_ERROR" -> {
                    if (!activeTrade) status = "ERROR"
                    updateOverlay()
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        ensureOverlay()
        registerReceiverSafe()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_HIDE_OVERLAY) {
            removeOverlayNow()
            stopSelf()
            return START_NOT_STICKY
        }
        ensureOverlay()
        updateOverlay()
        return START_STICKY
    }

    private fun resetState() {
        timeframe = "5S"
        nextSignal = "NO TRADE"
        nextConfidence = 0
        nextProbabilitySamples = 0
        nextTrend = "WAITING"
        signalLocked = false
        activeSignal = "NONE"
        activeConfidence = 0
        activeEntry = Double.NaN
        activeTrade = false
        lastEntry = Double.NaN
        lastExit = Double.NaN
        lastResult = "NONE"
        lastResultSignal = "NONE"
        status = "SCANNING"
        candleCount = 0
        quickSignal = "NO TRADE"
        quickProbability = 0
        quickSamples = 0
        quickStatus = "WAITING"
    }

    private fun ensureOverlay() {
        if (overlayView != null) return

        overlayView = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.rgb(57, 255, 20))
            setBackgroundColor(Color.TRANSPARENT)
            // Keep the window itself transparent so the Quotex chart remains visible.
            alpha = 1.0f
            gravity = Gravity.START
            setPadding(10, 8, 10, 8)
            includeFontPadding = false
            maxLines = 8
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
            },
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )

        // Fixed top-right position.
        params.gravity = Gravity.TOP or Gravity.END
        params.x = 12
        params.y = 24

        try {
            windowManager.addView(overlayView, params)
        } catch (_: Exception) {
            overlayView = null
            Toast.makeText(this, "Overlay permission required", Toast.LENGTH_LONG).show()
        }
    }

    private fun buildOverlayText(): String {
        val signal = when {
            activeTrade -> activeSignal
            signalLocked && (nextSignal == "CALL" || nextSignal == "PUT") -> nextSignal
            else -> quickSignal
        }
        val confidence = when {
            activeTrade -> activeConfidence
            signalLocked -> nextConfidence
            else -> quickProbability
        }
        val resultText = if (lastResult == "NONE") "-" else lastResult
        val state = when {
            candleCount <= 0 -> "WAITING FOR CANDLES"
            activeTrade -> "5S TRADE"
            signalLocked -> "SIGNAL READY"
            quickStatus.isNotBlank() -> quickStatus
            else -> status
        }

        return "5S • CANDLES: $candleCount\n" +
            "SIGNAL: $signal" + if (confidence > 0) " ($confidence%)" else "" + "\n" +
            "STATUS: $state • RESULT: $resultText"
    }

    private fun formatPrice(value: Double): String {
        if (value.isNaN() || value.isInfinite()) return "WAITING"
        return String.format(Locale.US, "%.2f", value)
    }

    private fun updateOverlay() {
        overlayView?.post { overlayView?.text = buildOverlayText() }
    }

    private fun removeOverlayNow() {
        val view = overlayView ?: return
        overlayView = null
        try { windowManager.removeViewImmediate(view) } catch (_: Exception) {}
    }

    private fun registerReceiverSafe() {
        if (receiverRegistered) return
        val filter = IntentFilter(ACTION_FRAME_STATUS)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                @Suppress("DEPRECATION") registerReceiver(receiver, filter)
            }
            receiverRegistered = true
        } catch (_: Exception) {
            receiverRegistered = false
        }
    }

    override fun onDestroy() {
        if (receiverRegistered) {
            try { unregisterReceiver(receiver) } catch (_: Exception) {}
            receiverRegistered = false
        }
        removeOverlayNow()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
