package com.example.screener

import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class OverlayService : Service() {

    companion object {
        private const val ACTION_FRAME_STATUS = "com.example.screener.FRAME_STATUS"
        const val ACTION_HIDE_OVERLAY = "com.example.screener.HIDE_OVERLAY"
        private const val CONFIDENCE_LEVEL = 90
    }

    private lateinit var windowManager: WindowManager
    private var overlayView: TextView? = null
    private var receiverRegistered = false

    private var timeframe = "1M"
    private var nextSignal = "NO TRADE"
    private var nextConfidence = 0
    private var nextTrend = "WAITING"
    private var signalLocked = false

    private var activeSignal = "NONE"
    private var activeConfidence = 0
    private var activeEntry = Double.NaN
    private var activeTrade = false

    private var lastEntry = Double.NaN
    private var lastExit = Double.NaN
    private var lastResult = "NONE"

    private var status = "SCANNING"
    private var candleCount = 0

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != ACTION_FRAME_STATUS) return

            timeframe = intent.getStringExtra("timeframe") ?: timeframe

            if (intent.hasExtra("count")) {
                candleCount = intent.getIntExtra("count", candleCount)
            }

            when (intent.getStringExtra("status")) {
                "CAPTURE_STARTED" -> {
                    resetState()
                    timeframe = intent.getStringExtra("timeframe") ?: "1M"
                    status = "SCANNING"
                    ensureOverlay()
                    updateOverlay()
                }

                "PROJECTION_STARTING", "IMAGE_READER_CREATED", "VIRTUAL_DISPLAY_CREATED",
                "FRAME_READY", "CANDLES_DETECTED", "CANDLE_DETECTION_WAITING", "HISTORY_WAITING",
                "LIVE_ANALYSIS", "CANDLE_RUNNING", "CANDLE_WAITING", "WAITING_NEW_CANDLE",
                "RESULT_WAITING_CANDLE_CONFIRMATION", "ANALYSIS_ERROR", "FRAME_ERROR" -> {
                    if (intent.getStringExtra("status") == "LIVE_ANALYSIS" &&
                        !activeTrade && !signalLocked
                    ) {
                        nextConfidence = intent.getIntExtra("confidence", nextConfidence)
                        nextTrend = intent.getStringExtra("trend") ?: nextTrend
                    }

                    if (!activeTrade && !signalLocked) status = "SCANNING"
                    updateOverlay()
                }

                "ANALYSIS_READY" -> {
                    val signal = intent.getStringExtra("signal")?.uppercase(Locale.US) ?: "NO TRADE"
                    val confidence = intent.getIntExtra("confidence", 0)
                    val trend = intent.getStringExtra("trend") ?: "UNKNOWN"

                    if ((signal == "CALL" || signal == "PUT") && confidence >= CONFIDENCE_LEVEL) {
                        nextSignal = signal
                        nextConfidence = confidence
                        nextTrend = trend
                        signalLocked = true
                        status = "SIGNAL LOCKED"
                    } else {
                        nextSignal = "NO TRADE"
                        nextConfidence = confidence
                        nextTrend = trend
                        signalLocked = false
                        status = "NO TRADE"
                    }
                    updateOverlay()
                }

                "TRADE_ENTRY" -> {
                    val signal = intent.getStringExtra("signal")?.uppercase(Locale.US) ?: "NO TRADE"
                    if (signal != "CALL" && signal != "PUT") return

                    activeSignal = signal
                    activeConfidence = intent.getIntExtra("confidence", nextConfidence)
                    activeEntry = intent.getDoubleExtra("entryPrice", Double.NaN)
                    lastEntry = activeEntry
                    activeTrade = true

                    nextSignal = "NO TRADE"
                    nextConfidence = 0
                    nextTrend = "WAITING"
                    signalLocked = false
                    status = "TRADE RUNNING"
                    updateOverlay()
                }

                "RESULT_READY" -> {
                    lastResult = intent.getStringExtra("result")?.uppercase(Locale.US) ?: "DRAW"
                    lastEntry = intent.getDoubleExtra("entryPrice", lastEntry)
                    lastExit = intent.getDoubleExtra("exitPrice", Double.NaN)

                    activeTrade = false
                    activeSignal = "NONE"
                    activeConfidence = 0
                    activeEntry = Double.NaN
                    status = "RESULT CONFIRMED"
                    updateOverlay()
                }

                "CAPTURE_STOPPED" -> {
                    removeOverlayNow()
                    resetState()
                }

                "CAPTURE_ERROR", "PROJECTION_ERROR", "VIRTUAL_DISPLAY_ERROR" -> {
                    if (!activeTrade) status = "ERROR"
                    updateOverlay()
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        ensureOverlay()
        registerReceiverSafe()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_HIDE_OVERLAY) {
            removeOverlayNow()
            stopSelf()
            return START_NOT_STICKY
        }
        ensureOverlay()
        updateOverlay()
        return START_STICKY
    }

    private fun resetState() {
        timeframe = "1M"
        nextSignal = "NO TRADE"
        nextConfidence = 0
        nextTrend = "WAITING"
        signalLocked = false
        activeSignal = "NONE"
        activeConfidence = 0
        activeEntry = Double.NaN
        activeTrade = false
        lastEntry = Double.NaN
        lastExit = Double.NaN
        lastResult = "NONE"
        status = "SCANNING"
        candleCount = 0
    }

    private fun ensureOverlay() {
        if (overlayView != null) return

        overlayView = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.rgb(57, 255, 20))
            setBackgroundColor(Color.BLACK)
            gravity = Gravity.START
            setPadding(10, 8, 10, 8)
            includeFontPadding = false
            maxLines = 8
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
            },
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.OPAQUE
        )

        // Fixed top-right position.
        params.gravity = Gravity.TOP or Gravity.END
        params.x = 12
        params.y = 24

        try {
            windowManager.addView(overlayView, params)
        } catch (_: Exception) {
            overlayView = null
            Toast.makeText(this, "Overlay permission required", Toast.LENGTH_LONG).show()
        }
    }

    private fun buildOverlayText(): String {
        val signal: String
        val confidence: Int
        val trend: String
        val entry: String
        val exit: String

        if (activeTrade) {
            signal = activeSignal
            confidence = activeConfidence
            trend = nextTrend.takeIf { it != "WAITING" } ?: "ACTIVE"
            entry = formatPrice(activeEntry)
            exit = "WAITING"
        } else if (signalLocked) {
            signal = nextSignal
            confidence = nextConfidence
            trend = nextTrend
            entry = "NEXT $timeframe OPEN"
            exit = "NEXT $timeframe CLOSE"
        } else if (lastResult != "NONE") {
            signal = "NO TRADE"
            confidence = 0
            trend = "WAITING"
            entry = formatPrice(lastEntry)
            exit = formatPrice(lastExit)
        } else {
            signal = "NO TRADE"
            confidence = nextConfidence
            trend = nextTrend
            entry = "WAITING"
            exit = "WAITING"
        }

        return "LIVE TRADE\n" +
            signal + "\n" +
            "Confidence: $confidence%\n" +
            "Trend: $trend\n" +
            "Entry: $entry\n" +
            "Exit: $exit\n" +
            "Status: $status\n" +
            "Candles scanned: $candleCount"
    }

    private fun formatPrice(value: Double): String {
        if (value.isNaN() || value.isInfinite()) return "WAITING"
        return String.format(Locale.US, "%.2f", value)
    }

    private fun updateOverlay() {
        overlayView?.post { overlayView?.text = buildOverlayText() }
    }

    private fun removeOverlayNow() {
        val view = overlayView ?: return
        overlayView = null
        try { windowManager.removeViewImmediate(view) } catch (_: Exception) {}
    }

    private fun registerReceiverSafe() {
        if (receiverRegistered) return
        val filter = IntentFilter(ACTION_FRAME_STATUS)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                @Suppress("DEPRECATION") registerReceiver(receiver, filter)
            }
            receiverRegistered = true
        } catch (_: Exception) {
            receiverRegistered = false
        }
    }

    override fun onDestroy() {
        if (receiverRegistered) {
            try { unregisterReceiver(receiver) } catch (_: Exception) {}
            receiverRegistered = false
        }
        removeOverlayNow()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
