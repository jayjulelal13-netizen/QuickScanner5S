# QuickScanner5S – Candle Engine Fixed

Focus: fix the screen-capture candle detector returning CANDLES: 0.

Changes:
- Remove ImageReader row padding before detector coordinates are used.
- Expand the detector to the actual chart width seen in the mobile layout.
- Keep the existing 5S quick engine and overlay.
- No external order placement.


V16 detector: adaptive red/green pixel classification, adaptive candle pitch, exact ImageReader crop, and tolerant OHLC candidate filtering.
