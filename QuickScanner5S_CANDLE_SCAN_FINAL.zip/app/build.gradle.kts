plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android { namespace = "com.example.quickscanner"; compileSdk = 35
    defaultConfig { applicationId = "com.example.quickscanner"; minSdk = 26; targetSdk = 35; versionCode = 2; versionName = "1.1-candle-scan" }
}

kotlin { jvmToolchain(17) }
