# QuickScanner5S FINAL

Dedicated 5-second quick scanner. The broker chart remains on 1M; the app derives 5-second observations from screen-capture frames. It does not place broker orders.

For GitHub Actions, upload this project archive at repository root and keep only one `.zip` project archive in the repository. The root `.github/workflows/build.yml` should extract the archive and build the APK.
