package com.example.quickscanner

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    companion object {
        private const val REQUEST_CAPTURE = 5105
        private const val ACTION_STATUS = "com.example.quickscanner.FRAME_STATUS"
        private const val ACTION_STOP = "com.example.quickscanner.STOP_CAPTURE"
        private const val ACTION_HIDE = "com.example.quickscanner.HIDE_OVERLAY"
    }

    private lateinit var signalBox: TextView
    private lateinit var statusText: TextView
    private lateinit var statsText: TextView
    private var running = false
    private var total = 0
    private var wins = 0
    private var losses = 0

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != ACTION_STATUS) return
            when (intent.getStringExtra("status")) {
                "CAPTURE_STARTED" -> { running = true; status("5S SCANNER STARTED") }
                "PROJECTION_STARTING" -> status("STARTING SCREEN CAPTURE...")
                "PROJECTION_CREATED" -> status("SCREEN CAPTURE READY")
                "IMAGE_READER_CREATED" -> status("READING LIVE SCREEN...")
                "VIRTUAL_DISPLAY_CREATED" -> status("SCREEN READY • SCANNING 5S")
                "CANDLES_DETECTED" -> {
                    val n = intent.getIntExtra("count", 0)
                    status("LIVE CHART DETECTED • CANDLES: $n")
                }
                "CANDLE_DETECTION_WAITING", "NO_CHART_WAITING" -> status("WAITING FOR REAL CHART CANDLES...")
                "QUICK_5S" -> updateQuick(intent)
                "FRAME_ERROR" -> status("FRAME ERROR • WAITING FOR NEXT FRAME")
                "ANALYSIS_ERROR" -> status("ANALYSIS ERROR • CAPTURE CONTINUES")
                "CAPTURE_ERROR", "PROJECTION_ERROR" -> { running = false; status("CAPTURE ERROR • START AGAIN") }
                "CAPTURE_STOPPED" -> { running = false; signal("5S QUICK\n\nNO TRADE\n\nCapture stopped", Color.LTGRAY); status("CAPTURE STOPPED") }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    override fun onStart() {
        super.onStart()
        try {
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, IntentFilter(ACTION_STATUS), Context.RECEIVER_NOT_EXPORTED)
            else registerReceiver(receiver, IntentFilter(ACTION_STATUS))
        } catch (_: Throwable) {}
    }

    override fun onStop() {
        try { unregisterReceiver(receiver) } catch (_: Throwable) {}
        super.onStop()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18,18,18,28) }
        scroll.addView(root)

        root.addView(TextView(this).apply {
            text = "QUICK SCANNER 5S"
            textSize = 25f; gravity = Gravity.CENTER; setPadding(8,12,8,18)
        }, full())

        signalBox = TextView(this).apply {
            text = "5S QUICK\n\nNO TRADE\n\nWaiting for chart..."
            textSize = 20f; gravity = Gravity.CENTER; setPadding(18,32,18,32); setBackgroundColor(Color.LTGRAY)
        }
        root.addView(signalBox, full())

        root.addView(TextView(this).apply {
            text = "Dedicated 5-second scanner\nChart source: live screen frames\n5S candles are built from live screen price samples."
            textSize = 15f; gravity = Gravity.CENTER; setPadding(8,18,8,18)
        }, full())

        root.addView(button("ENABLE OVERLAY") { enableOverlay() }, full())
        root.addView(button("START SCREEN CAPTURE") { requestCapture() }, full())
        root.addView(button("STOP CAPTURE") { stopCapture() }, full())
        root.addView(button("RESET") { reset() }, full())

        statsText = TextView(this).apply { textSize = 16f; gravity = Gravity.CENTER; setPadding(10,18,10,18) }
        root.addView(statsText, full())

        root.addView(TextView(this).apply {
            text = "RULES\n\n• 5S only — no 1M/5M/15M selector\n• CALL/PUT requires 90%+ setup confidence\n• Below 90% = NO TRADE\n• No fake 90% historical win-rate\n• One 5-second observation for demo result\n• Scanner does not place broker orders\n• Keep the chart visible while screen capture is running"
            textSize = 14f; setPadding(10,10,10,20)
        }, full())

        statusText = TextView(this).apply { text = "Status: Ready"; textSize = 15f; setPadding(10,15,10,15) }
        root.addView(statusText, full())
        updateStats()
        setContentView(scroll)
    }

    private fun updateQuick(i: Intent) {
        val sig = i.getStringExtra("quickSignal")?.uppercase() ?: "NO TRADE"
        val conf = i.getIntExtra("quickProbability", 0)
        val samples = i.getIntExtra("quickSamples", 0)
        val st = i.getStringExtra("quickStatus") ?: "WAITING"
        val result = i.getStringExtra("quickResult") ?: "NONE"
        signal("5S QUICK\n\n$sig\n\nConfidence: ${conf}%\nSamples: $samples\nResult: $result\nExpiry: 5 seconds\nStatus: $st", if (sig == "CALL" || sig == "PUT") Color.rgb(190,240,190) else Color.LTGRAY)
        if (result == "WIN" || result == "LOSS") { total++; if (result == "WIN") wins++ else losses++; updateStats() }
        status("5S • $sig • ${conf}% • $st")
    }

    private fun signal(text: String, bg: Int) { signalBox.text = text; signalBox.setBackgroundColor(bg) }
    private fun status(text: String) { statusText.text = "Status: $text" }
    private fun updateStats() { statsText.text = "DEMO RESULTS\nTotal: $total   WIN: $wins   LOSS: $losses\nAccuracy: ${if (total == 0) 0 else wins * 100 / total}%" }
    private fun reset() { total=0; wins=0; losses=0; signal("5S QUICK\n\nNO TRADE\n\nWaiting for chart...", Color.LTGRAY); updateStats(); status("RESET COMPLETE") }

    private fun requestCapture() {
        try {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE)
            status("REQUESTING SCREEN CAPTURE...")
        } catch (e: Exception) { status("SCREEN CAPTURE ERROR • ${e.message}") }
    }

    @Deprecated("Android framework callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_CAPTURE || resultCode != RESULT_OK || data == null) { status("SCREEN CAPTURE CANCELLED"); return }
        try {
            val service = Intent(this, CaptureService::class.java).apply {
                action = "com.example.quickscanner.START_CAPTURE"
                putExtra("resultCode", resultCode)
                putExtra("data", data)
                putExtra("timeframe", "5S")
                putExtra("quickMode", true)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service) else startService(service)
            running = true
            status("CAPTURE SERVICE STARTING • 5S QUICK")
        } catch (e: Exception) { status("SERVICE ERROR • ${e.message}") }
    }

    private fun stopCapture() {
        try { startService(Intent(this, CaptureService::class.java).apply { action = ACTION_STOP }) } catch (_: Throwable) {}
        try { startService(Intent(this, OverlayService::class.java).apply { action = ACTION_HIDE }) } catch (_: Throwable) {}
        running = false
        status("STOPPING CAPTURE...")
    }

    private fun enableOverlay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            status("ALLOW DISPLAY OVER OTHER APPS, THEN RETURN")
            return
        }
        try { startService(Intent(this, OverlayService::class.java)) ; status("OVERLAY ENABLED") } catch (e: Exception) { status("OVERLAY ERROR • ${e.message}") }
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply { text = label; textSize = 16f; setOnClickListener { action() } }
    private fun full() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
}
