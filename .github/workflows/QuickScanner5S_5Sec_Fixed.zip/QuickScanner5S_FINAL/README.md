# QuickScanner5S

5-second screen scanner.

- MediaProjection live screen capture
- Visible candle detection preserved
- Live price samples are aggregated into completed 5-second OHLC candles
- Signal engine runs only on completed 5S candles
- CALL/PUT only at 90%+ analyzer confidence; otherwise NO TRADE
- Result is settled on the following 5-second candle
- No broker orders are placed by the app

Important: if the broker chart is not natively 5S, the 5S OHLC is screen-sampled/app-derived; it is not historical broker-provided 5S data. Keep the chart visible and stable while capture is running.
