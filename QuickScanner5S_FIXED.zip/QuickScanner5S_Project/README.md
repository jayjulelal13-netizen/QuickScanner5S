# QuickScanner5S

Dedicated second Android app for 5-second quick scanning.

- Separate package: `com.example.quickscanner`
- Uses MediaProjection live screen frames.
- If the broker has no native 5-second candles, the app derives a 5-second observation from successive frames; it does not pretend those are broker-native candles.
- CALL/PUT requires the 90% setup-quality gate.
- No broker orders are placed.
- Keep the broker chart visible while capture is running.
