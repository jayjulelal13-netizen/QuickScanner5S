# QuickScanner5S – 5S Engine + Candle Scan FINAL

This build restores the stable 5-second quick engine and the candle-body grouping detector.

- Broker chart remains on 1M.
- 5S engine observes successive captured frames in 5-second buckets.
- Candle detector groups real red/green candle pixels instead of using unstable peak-only detection.
- CALL/PUT remains locked to the existing 90% setup-confidence gate.
- Demo scanner only; it does not place broker orders.
