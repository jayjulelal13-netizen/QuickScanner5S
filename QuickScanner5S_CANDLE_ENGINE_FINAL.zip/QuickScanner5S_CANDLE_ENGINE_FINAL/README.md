# QuickScanner5S — compact 5S candle engine

This build keeps the screen-capture/candle engine and uses a compact black right-side overlay:

- 5S SCANNER
- CONFIDENCE
- CANDLES
- STATUS (CALL/PUT only when the 90% gate is passed)
- RESULT (rolling last 5 demo results, e.g. 4/5 or 5/5)

The detector excludes the top banner/overlay area and right price scale, adapts to capture scaling, and reports the raw detected candle count before the history gate.

No external order placement is implemented. Confidence is a strategy threshold/score, not a guarantee of winning trades.
