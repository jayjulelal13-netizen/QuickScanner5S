plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.screener"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.screener"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "5S-CANDLE-ENGINE-FINAL"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
